--
-- Database: `dbrumah_makan`
--

-- --------------------------------------------------------

--
-- Table structure for table `bahan_makanan`
--

CREATE TABLE `bahan_makanan` (
  `kode_bahan` varchar(10) NOT NULL,
  `nama` varchar(10) DEFAULT NULL,
  `nama_bahan` varchar(100) NOT NULL,
  `jenis_bahan` varchar(50) DEFAULT NULL,
  `tgl_produksi` date DEFAULT NULL,
  `tgl_kadaluarsa` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bahan_makanan`
--

INSERT INTO `bahan_makanan` (`kode_bahan`, `nama`, `nama_bahan`, `jenis_bahan`, `tgl_produksi`, `tgl_kadaluarsa`) VALUES
('BM001B', NULL, 'Cabe Merah, Bawang Putih, Lada hitam, Garam, Gula, Jahe', 'Bumbu', '2018-06-13', '2018-06-13'),
('BM001D', NULL, 'Daging Sapi', 'Daging', '2018-06-13', '2018-06-13'),
('BM001F', NULL, 'Lemon, Tomat, Wortel, Jeruk, Apel, Melon', 'Buah', '2018-06-13', '2019-06-02'),
('BM001S', NULL, 'Bayam, Kangkung, Sawi, Koll', 'Sayuran', '2018-06-13', '2018-06-13'),
('BM002D', NULL, 'Daging Ayam', 'Daging', '2018-06-13', '2018-06-13');

-- --------------------------------------------------------

--
-- Table structure for table `makanan_minuman`
--

CREATE TABLE `makanan_minuman` (
  `id_list` varchar(10) NOT NULL,
  `nama_menu` varchar(100) DEFAULT NULL,
  `kategori` varchar(10) DEFAULT NULL,
  `harga` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `makanan_minuman`
--

INSERT INTO `makanan_minuman` (`id_list`, `nama_menu`, `kategori`, `harga`) VALUES
('001', 'Nasi Goreng', 'Makanan', 15000),
('002', 'Sate', 'Makanan', 20000),
('003', 'Ayam Goreng', 'Makanan', 15000),
('004', 'smoked ham', 'Makanan', 30000),
('005', 'Cold Fish', 'Makanan', 50000),
('006', 'Large Veriety Of Cold Dishes', 'Makanan', 100000);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `jenis_kelamin` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`nama`, `alamat`, `jenis_kelamin`) VALUES
('Bratadirja', 'Parigi Lama', 'laki');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `kode_menu` varchar(10) NOT NULL,
  `id_pesanan` varchar(10) DEFAULT NULL,
  `jenis_menu` varchar(50) DEFAULT NULL,
  `kategori` varchar(10) DEFAULT NULL,
  `satuan` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`kode_menu`, `id_pesanan`, `jenis_menu`, `kategori`, `satuan`) VALUES
('M001', NULL, 'Breakfast Menu', 'Tersedia', 'Porsi     '),
('M002', NULL, 'Lunch Menu', 'Tersedia', 'Porsi'),
('M003', NULL, 'Dinner Menu', 'Tersedia', 'Porsi'),
('M004', NULL, 'Supper Menu', 'Tersedia', 'Porsi'),
('M005', NULL, 'Banquet Menu', 'Tersedia', 'Porsi'),
('M006', NULL, 'Buffet Menu', 'Tersedia', 'Porsi');

-- --------------------------------------------------------

--
-- Table structure for table `nota_pesanan`
--

CREATE TABLE `nota_pesanan` (
  `id_pesanan` varchar(10) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `jmlh_pesanan` int(10) NOT NULL,
  `tgl_pesanan` date DEFAULT NULL,
  `total` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nota_pesanan`
--

INSERT INTO `nota_pesanan` (`id_pesanan`, `user_id`, `jmlh_pesanan`, `tgl_pesanan`, `total`) VALUES
('PE001', 'Andika', 1, '2018-06-14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pelayan`
--

CREATE TABLE `pelayan` (
  `id_pelayan` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelayan`
--

INSERT INTO `pelayan` (`id_pelayan`, `nama`, `jenis_kelamin`) VALUES
('PL001', 'Nadif Syahputra', 'laki'),
('PL002', 'Zahra Onasis', 'perempuan');

-- --------------------------------------------------------

--
-- Table structure for table `pemasok`
--

CREATE TABLE `pemasok` (
  `id_pemasok` varchar(10) NOT NULL,
  `nama` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pembeli`
--

CREATE TABLE `pembeli` (
  `id_pembeli` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembeli`
--

INSERT INTO `pembeli` (`id_pembeli`, `nama`, `alamat`) VALUES
('K001', 'Galih Hermawan', 'Jl. Buah Batu');

-- --------------------------------------------------------

--
-- Table structure for table `retail_berisi`
--

CREATE TABLE `retail_berisi` (
  `kode_menu` varchar(10) DEFAULT NULL,
  `id_list` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `retail_berisi`
--

INSERT INTO `retail_berisi` (`kode_menu`, `id_list`) VALUES
('M001', '001'),
('M002', '002'),
('M003', '003'),
('M004', '004'),
('M005', '005'),
('M006', '006');

-- --------------------------------------------------------

--
-- Table structure for table `retail_dibayar`
--

CREATE TABLE `retail_dibayar` (
  `id_struk` int(3) NOT NULL,
  `id_pembeli` varchar(10) NOT NULL,
  `tgl_pembayaran` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `retail_diolah`
--

CREATE TABLE `retail_diolah` (
  `id_pesanan` varchar(10) NOT NULL,
  `id_staff` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `retail_melayani`
--

CREATE TABLE `retail_melayani` (
  `id_pelayan` varchar(10) NOT NULL,
  `id_pembeli` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `retail_mendapat`
--

CREATE TABLE `retail_mendapat` (
  `id_pembeli` varchar(10) NOT NULL,
  `id_pesanan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `retail_suplai`
--

CREATE TABLE `retail_suplai` (
  `id_pemasok` varchar(10) NOT NULL,
  `kode_bahan` varchar(10) NOT NULL,
  `tgl_pemasok` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `retail_terdapat`
--

CREATE TABLE `retail_terdapat` (
  `id_list` varchar(10) NOT NULL,
  `kode_bahan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_dapur`
--

CREATE TABLE `staff_dapur` (
  `id_staff` varchar(10) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `jenis_kelamin` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_dapur`
--

INSERT INTO `staff_dapur` (`id_staff`, `nama`, `alamat`, `jenis_kelamin`) VALUES
('SD001', 'Vina', 'Jl. Gunung Kapur', 'perempuan'),
('SD002', 'Lala Marion', 'Jl. Cinta Sejati', 'perempuan'),
('SD003', 'Aditya Ramadan', 'Jl. Tidore', 'laki');

-- --------------------------------------------------------

--
-- Table structure for table `struk`
--

CREATE TABLE `struk` (
  `id_struk` int(3) NOT NULL,
  `nomor_transaksi` varchar(50) NOT NULL,
  `jmlh_transaksi` int(3) DEFAULT NULL,
  `tgl_transaksi` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `struk`
--

INSERT INTO `struk` (`id_struk`, `nomor_transaksi`, `jmlh_transaksi`, `tgl_transaksi`) VALUES
(1, 'TR0001', 1, '2018-06-14'),
(2, 'TR0001', 1, '2018-06-14');

-- --------------------------------------------------------

--
-- Table structure for table `tmp_transaksi_pemasok`
--

CREATE TABLE `tmp_transaksi_pemasok` (
  `id_tmp` int(10) NOT NULL,
  `id_pemasok` varchar(10) NOT NULL,
  `nama_bahan` varchar(100) NOT NULL,
  `harga` int(10) NOT NULL,
  `jumlah` int(3) NOT NULL,
  `id_session` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_transaksi_pemesanan`
--

CREATE TABLE `tmp_transaksi_pemesanan` (
  `id_tmp` int(5) NOT NULL,
  `id_pembeli` varchar(10) DEFAULT NULL,
  `nama_menu` varchar(100) DEFAULT NULL,
  `harga` int(10) DEFAULT NULL,
  `jumlah` int(3) DEFAULT NULL,
  `id_session` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_pemasok`
--

CREATE TABLE `transaksi_pemasok` (
  `no_pembelian` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `tgl_pemasok` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_pemasok_item`
--

CREATE TABLE `transaksi_pemasok_item` (
  `id_item` int(3) NOT NULL,
  `no_pembelian` varchar(10) NOT NULL,
  `id_pemasok` varchar(10) NOT NULL,
  `nama_bahan` varchar(100) NOT NULL,
  `harga` int(10) NOT NULL,
  `jumlah` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_pemesanan`
--

CREATE TABLE `transaksi_pemesanan` (
  `no_transaksi` varchar(10) NOT NULL,
  `id_pemesanan` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `userid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi_pemesanan`
--

INSERT INTO `transaksi_pemesanan` (`no_transaksi`, `id_pemesanan`, `nama`, `tanggal`, `alamat`, `userid`) VALUES
('TR0001', 'PE001', 'Galih Hermawan', '2018-06-14', 'Jl. Buah Batu', 'Andika');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_pemesanan_item`
--

CREATE TABLE `transaksi_pemesanan_item` (
  `id_item` int(2) NOT NULL,
  `no_transaksi` varchar(10) NOT NULL,
  `id_pembeli` varchar(10) NOT NULL,
  `nama_menu` varchar(100) NOT NULL,
  `harga` int(10) NOT NULL,
  `jumlah` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi_pemesanan_item`
--

INSERT INTO `transaksi_pemesanan_item` (`id_item`, `no_transaksi`, `id_pembeli`, `nama_menu`, `harga`, `jumlah`) VALUES
(1, 'TR0001', 'K001', 'Nasi', 15000, 1),
(2, 'TR0001', 'K001', 'Large', 100000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` varchar(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `jenis_kelamin` varchar(10) DEFAULT NULL,
  `level` enum('kasir','admin','manager') NOT NULL DEFAULT 'kasir'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `password`, `nama`, `alamat`, `jenis_kelamin`, `level`) VALUES
('Andika', 'andika10', 'Andika Bratadirja', 'Jl. Pajajran Dalam', 'laki', 'admin'),
('Brata', '', 'Bratadirja', 'Jl. Kadungora', 'laki', 'manager'),
('Nabila', 'nabila10', 'Nabila Hayuni', 'Jl. Parigi Lama', 'perempuan', 'kasir');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bahan_makanan`
--
ALTER TABLE `bahan_makanan`
  ADD PRIMARY KEY (`kode_bahan`),
  ADD KEY `nama` (`nama`);

--
-- Indexes for table `makanan_minuman`
--
ALTER TABLE `makanan_minuman`
  ADD PRIMARY KEY (`id_list`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`nama`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`kode_menu`),
  ADD KEY `menu_ibfk_1` (`id_pesanan`);

--
-- Indexes for table `nota_pesanan`
--
ALTER TABLE `nota_pesanan`
  ADD PRIMARY KEY (`id_pesanan`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pelayan`
--
ALTER TABLE `pelayan`
  ADD PRIMARY KEY (`id_pelayan`);

--
-- Indexes for table `pemasok`
--
ALTER TABLE `pemasok`
  ADD PRIMARY KEY (`id_pemasok`);

--
-- Indexes for table `pembeli`
--
ALTER TABLE `pembeli`
  ADD PRIMARY KEY (`id_pembeli`);

--
-- Indexes for table `retail_berisi`
--
ALTER TABLE `retail_berisi`
  ADD KEY `retail_berisi_ibfk_1` (`kode_menu`),
  ADD KEY `retail_berisi_ibfk_2` (`id_list`);

--
-- Indexes for table `retail_dibayar`
--
ALTER TABLE `retail_dibayar`
  ADD KEY `id_struk` (`id_struk`),
  ADD KEY `id_pembeli` (`id_pembeli`);

--
-- Indexes for table `retail_diolah`
--
ALTER TABLE `retail_diolah`
  ADD KEY `id_pesanan` (`id_pesanan`),
  ADD KEY `id_staff` (`id_staff`);

--
-- Indexes for table `retail_melayani`
--
ALTER TABLE `retail_melayani`
  ADD KEY `id_pelayan` (`id_pelayan`),
  ADD KEY `id_pembeli` (`id_pembeli`);

--
-- Indexes for table `retail_mendapat`
--
ALTER TABLE `retail_mendapat`
  ADD KEY `id_pembeli` (`id_pembeli`),
  ADD KEY `id_pesanan` (`id_pesanan`);

--
-- Indexes for table `retail_suplai`
--
ALTER TABLE `retail_suplai`
  ADD KEY `id_pemasok` (`id_pemasok`),
  ADD KEY `kode_bahan` (`kode_bahan`);

--
-- Indexes for table `retail_terdapat`
--
ALTER TABLE `retail_terdapat`
  ADD KEY `id_list` (`id_list`),
  ADD KEY `kode_bahan` (`kode_bahan`);

--
-- Indexes for table `staff_dapur`
--
ALTER TABLE `staff_dapur`
  ADD PRIMARY KEY (`id_staff`);

--
-- Indexes for table `struk`
--
ALTER TABLE `struk`
  ADD PRIMARY KEY (`id_struk`);

--
-- Indexes for table `tmp_transaksi_pemasok`
--
ALTER TABLE `tmp_transaksi_pemasok`
  ADD PRIMARY KEY (`id_tmp`);

--
-- Indexes for table `tmp_transaksi_pemesanan`
--
ALTER TABLE `tmp_transaksi_pemesanan`
  ADD PRIMARY KEY (`id_tmp`);

--
-- Indexes for table `transaksi_pemasok`
--
ALTER TABLE `transaksi_pemasok`
  ADD PRIMARY KEY (`no_pembelian`);

--
-- Indexes for table `transaksi_pemasok_item`
--
ALTER TABLE `transaksi_pemasok_item`
  ADD PRIMARY KEY (`id_item`);

--
-- Indexes for table `transaksi_pemesanan`
--
ALTER TABLE `transaksi_pemesanan`
  ADD PRIMARY KEY (`no_transaksi`);

--
-- Indexes for table `transaksi_pemesanan_item`
--
ALTER TABLE `transaksi_pemesanan_item`
  ADD PRIMARY KEY (`id_item`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `struk`
--
ALTER TABLE `struk`
  MODIFY `id_struk` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tmp_transaksi_pemasok`
--
ALTER TABLE `tmp_transaksi_pemasok`
  MODIFY `id_tmp` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tmp_transaksi_pemesanan`
--
ALTER TABLE `tmp_transaksi_pemesanan`
  MODIFY `id_tmp` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `transaksi_pemasok_item`
--
ALTER TABLE `transaksi_pemasok_item`
  MODIFY `id_item` int(3) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaksi_pemesanan_item`
--
ALTER TABLE `transaksi_pemesanan_item`
  MODIFY `id_item` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `bahan_makanan`
--
ALTER TABLE `bahan_makanan`
  ADD CONSTRAINT `bahan_makanan_ibfk_1` FOREIGN KEY (`nama`) REFERENCES `manager` (`nama`);

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`id_pesanan`) REFERENCES `nota_pesanan` (`id_pesanan`);

--
-- Constraints for table `nota_pesanan`
--
ALTER TABLE `nota_pesanan`
  ADD CONSTRAINT `nota_pesanan_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `retail_berisi`
--
ALTER TABLE `retail_berisi`
  ADD CONSTRAINT `retail_berisi_ibfk_1` FOREIGN KEY (`kode_menu`) REFERENCES `menu` (`kode_menu`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `retail_berisi_ibfk_2` FOREIGN KEY (`id_list`) REFERENCES `makanan_minuman` (`id_list`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `retail_dibayar`
--
ALTER TABLE `retail_dibayar`
  ADD CONSTRAINT `retail_dibayar_ibfk_1` FOREIGN KEY (`id_struk`) REFERENCES `struk` (`id_struk`),
  ADD CONSTRAINT `retail_dibayar_ibfk_2` FOREIGN KEY (`id_pembeli`) REFERENCES `pembeli` (`id_pembeli`);

--
-- Constraints for table `retail_diolah`
--
ALTER TABLE `retail_diolah`
  ADD CONSTRAINT `retail_diolah_ibfk_1` FOREIGN KEY (`id_pesanan`) REFERENCES `nota_pesanan` (`id_pesanan`),
  ADD CONSTRAINT `retail_diolah_ibfk_2` FOREIGN KEY (`id_staff`) REFERENCES `staff_dapur` (`id_staff`);

--
-- Constraints for table `retail_melayani`
--
ALTER TABLE `retail_melayani`
  ADD CONSTRAINT `retail_melayani_ibfk_1` FOREIGN KEY (`id_pelayan`) REFERENCES `pelayan` (`id_pelayan`),
  ADD CONSTRAINT `retail_melayani_ibfk_2` FOREIGN KEY (`id_pembeli`) REFERENCES `pembeli` (`id_pembeli`);

--
-- Constraints for table `retail_mendapat`
--
ALTER TABLE `retail_mendapat`
  ADD CONSTRAINT `retail_mendapat_ibfk_1` FOREIGN KEY (`id_pembeli`) REFERENCES `pembeli` (`id_pembeli`),
  ADD CONSTRAINT `retail_mendapat_ibfk_2` FOREIGN KEY (`id_pesanan`) REFERENCES `nota_pesanan` (`id_pesanan`);

--
-- Constraints for table `retail_suplai`
--
ALTER TABLE `retail_suplai`
  ADD CONSTRAINT `retail_suplai_ibfk_1` FOREIGN KEY (`id_pemasok`) REFERENCES `pemasok` (`id_pemasok`),
  ADD CONSTRAINT `retail_suplai_ibfk_2` FOREIGN KEY (`kode_bahan`) REFERENCES `bahan_makanan` (`kode_bahan`);

--
-- Constraints for table `retail_terdapat`
--
ALTER TABLE `retail_terdapat`
  ADD CONSTRAINT `retail_terdapat_ibfk_1` FOREIGN KEY (`id_list`) REFERENCES `makanan_minuman` (`id_list`),
  ADD CONSTRAINT `retail_terdapat_ibfk_2` FOREIGN KEY (`kode_bahan`) REFERENCES `bahan_makanan` (`kode_bahan`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
